console.log('i am here')

class myHeader extends HTMLElement {
    connectedCallback () {
        this.innerHTML = `
            <header>
                <h1>A Portfolio</h1>
                <div id="navigationButtons">
                    <button onclick="window.location.href = 'maingame.html'">HOME</button>
                    <button onclick="window.location.href = 'GWorld.html'">GameWorld</button>
                    <button onclick="window.location.href = 'game1.html'">Game 1</button>
                    <button onclick="window.location.href = 'game2.html'">Game 2</button>
                    <button onclick="window.location.href = 'game3.html'">Game 3</button>
                </div>
            </header>`;
    }
}

class myFooter extends HTMLElement {
    connectedCallback () {
        this.innerHTML = `
            <footer>
                <p>This'll be the footer</p>
            </footer>`;
    }
}

customElements.define ('my-header', myHeader)
customElements.define ('my-footer', myFooter)